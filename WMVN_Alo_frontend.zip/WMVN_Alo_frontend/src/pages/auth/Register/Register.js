import React from "react";

const Register = () => {
  return <div style={{ color: "white" }}>Register</div>;
};

export default Register;
