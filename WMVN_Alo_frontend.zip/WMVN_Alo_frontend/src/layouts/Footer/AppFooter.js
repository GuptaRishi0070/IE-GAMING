import React from 'react'

const AppFooter = () => {
  return (
    <div>
      AppFooter
    </div>
  )
}

export default AppFooter
